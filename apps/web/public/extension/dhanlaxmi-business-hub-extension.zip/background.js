// src/background.ts
chrome.runtime.onInstalled.addListener(() => {
  console.info("[dlbh] extension installed");
});
//# sourceMappingURL=background.js.map
