// ../../packages/rules/dist/helpers.js
function isSiteTotalRow(name) {
  return /^total$/i.test(name.trim());
}
function matchesAny(productName, patterns, mode) {
  const hay = productName.toLowerCase();
  for (const pattern of patterns) {
    const needle = String(pattern || "").trim().toLowerCase();
    if (!needle)
      continue;
    if (mode === "exact") {
      if (hay === needle)
        return true;
    } else if (hay.includes(needle)) {
      return true;
    }
  }
  return false;
}
function numberOrZero(value) {
  if (value == null || value === "")
    return 0;
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : 0;
  }
  const cleaned = String(value).replace(/[₹,\s]/g, "");
  const number = Number(cleaned);
  return Number.isFinite(number) ? number : 0;
}
function round2(value) {
  return Math.round(value * 100) / 100;
}

// ../../packages/rules/dist/calculate.js
function calculateBusiness(rows, rules) {
  let totalBusiness = 0;
  let turnover = null;
  const details = [];
  const ignoredProducts = [];
  const halfProducts = [];
  let renewalHalfAmount = 0;
  for (const row of rows) {
    const name = String(row.productName || "").trim();
    if (!name)
      continue;
    if (isSiteTotalRow(name)) {
      if (rules.turnoverFromSiteTotalRow) {
        turnover = numberOrZero(row.total);
      }
      details.push({
        productName: name,
        role: "site_total",
        counted: 0,
        turnoverValue: turnover
      });
      continue;
    }
    if (matchesAny(name, rules.ignoreProducts, rules.match)) {
      ignoredProducts.push(name);
      details.push({
        productName: name,
        role: "ignore",
        counted: 0,
        personalNew: row.personalNew,
        personalRenewal: row.personalRenewal,
        groupNew: row.groupNew,
        groupRenewal: row.groupRenewal
      });
      continue;
    }
    const cols = rules.columns;
    const newAmount = (cols.personalNew ? numberOrZero(row.personalNew) : 0) + (cols.groupNew ? numberOrZero(row.groupNew) : 0);
    const renewalAmount = (cols.personalRenewal ? numberOrZero(row.personalRenewal) : 0) + (cols.groupRenewal ? numberOrZero(row.groupRenewal) : 0);
    const halfProduct = matchesAny(name, rules.halfProducts, rules.match);
    const countedNew = halfProduct ? newAmount * 0.5 : newAmount;
    const countedRenewal = rules.halfAllRenewal ? renewalAmount * 0.5 : renewalAmount;
    const counted = countedNew + countedRenewal;
    if (halfProduct) {
      halfProducts.push(name);
    }
    if (rules.halfAllRenewal && renewalAmount > 0) {
      renewalHalfAmount += renewalAmount;
    }
    totalBusiness += counted;
    details.push({
      productName: name,
      role: halfProduct ? "half_product" : "full_new",
      counted,
      countedNew,
      countedRenewal,
      personalNew: row.personalNew,
      personalRenewal: row.personalRenewal,
      groupNew: row.groupNew,
      groupRenewal: row.groupRenewal
    });
  }
  return {
    totalBusiness: round2(totalBusiness),
    turnover: turnover == null ? null : round2(turnover),
    ignoredProducts,
    halfProducts,
    renewalHalf: {
      applied: rules.halfAllRenewal,
      rawRenewalTotal: round2(renewalHalfAmount),
      countedRenewalTotal: round2(renewalHalfAmount * 0.5)
    },
    details
  };
}

// ../../packages/rules/dist/default-rules.js
var defaultRulesRaw = {
  version: 1,
  notes: "Is file ko edit karke ignore/half lists badal sakte ho. Code isko padhega.",
  match: "includes",
  ignoreProducts: ["180 DAYS 7%", "DDS 90DAYS NEW"],
  halfProducts: ["MIP", "12XFD WSC 10.00%", "XFD 12M 9.75 NEW"],
  halfAllRenewal: true,
  skipSiteTotalRow: true,
  turnoverFromSiteTotalRow: true,
  columns: {
    personalNew: true,
    personalRenewal: true,
    groupNew: true,
    groupRenewal: true
  }
};

// ../../packages/rules/dist/normalize.js
function normalizeRules(raw = {}) {
  const match = raw.match === "exact" ? "exact" : "includes";
  return {
    version: raw.version ?? 1,
    match,
    ignoreProducts: raw.ignoreProducts || [],
    halfProducts: raw.halfProducts || [],
    halfAllRenewal: raw.halfAllRenewal !== false,
    skipSiteTotalRow: raw.skipSiteTotalRow !== false,
    turnoverFromSiteTotalRow: raw.turnoverFromSiteTotalRow !== false,
    columns: {
      personalNew: raw.columns?.personalNew !== false,
      personalRenewal: raw.columns?.personalRenewal !== false,
      groupNew: raw.columns?.groupNew !== false,
      groupRenewal: raw.columns?.groupRenewal !== false
    }
  };
}

// ../../packages/rules/dist/index.js
var defaultRules = normalizeRules(defaultRulesRaw);

// ../../packages/shared/dist/constants.js
var PRODUCTION_WEBSITE_URL = "https://dhanlaxmi-business-hub.vercel.app";

// src/storage.ts
var TOKEN_KEY = "token";
var API_BASE_KEY = "apiBase";
var EMAIL_KEY = "email";
var DEFAULT_API_BASE = PRODUCTION_WEBSITE_URL;
async function getApiBase() {
  const data = await chrome.storage.local.get(API_BASE_KEY);
  return data[API_BASE_KEY] || DEFAULT_API_BASE;
}
async function setApiBase(url) {
  await chrome.storage.local.set({ [API_BASE_KEY]: url.replace(/\/$/, "") });
}
async function getToken() {
  const data = await chrome.storage.local.get(TOKEN_KEY);
  return data[TOKEN_KEY] || null;
}
async function setSession(token, email) {
  await chrome.storage.local.set({ [TOKEN_KEY]: token, [EMAIL_KEY]: email });
}
async function getEmail() {
  const data = await chrome.storage.local.get(EMAIL_KEY);
  return data[EMAIL_KEY] || null;
}
async function clearSession() {
  await chrome.storage.local.remove([TOKEN_KEY, EMAIL_KEY]);
}

// src/api.ts
async function request(path, init = {}, auth = true) {
  const base = await getApiBase();
  const headers = new Headers(init.headers);
  if (!headers.has("Content-Type") && init.body) {
    headers.set("Content-Type", "application/json");
  }
  if (auth) {
    const token = await getToken();
    if (!token) throw new Error("Pehle website account se login karo.");
    headers.set("Authorization", `Bearer ${token}`);
  }
  let res;
  try {
    res = await fetch(`${base}${path}`, { ...init, headers });
  } catch {
    throw new Error(
      `Network fail \u2014 API base check karo (${base}). Website chal raha hai?`
    );
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `API failed (${res.status})`);
  }
  return data;
}
async function login(email, password) {
  return request(
    "/api/auth/login",
    { method: "POST", body: JSON.stringify({ email, password }) },
    false
  );
}
async function saveCapture(body) {
  const data = await request("/api/captures", {
    method: "POST",
    body: JSON.stringify(body)
  });
  return data.capture;
}

// src/messages.ts
var MSG_EXTRACT = "DLBH_EXTRACT_PAGE";

// src/popup.ts
var DHAN_HOST = "login.dhan-laxmi.co.in";
var authStatus = el("auth-status");
var loginForm = el("login-form");
var logoutBtn = el("logout-btn");
var openDashBtn = el("open-dash-btn");
var authedActions = el("authed-actions");
var emailInput = el("email");
var passwordInput = el("password");
var apiBaseInput = el("api-base");
var accountIdInput = el("account-id");
var accountNameInput = el("account-name");
var calcBtn = el("calc-btn");
var statusEl = el("status");
var previewEl = el("preview");
function el(id) {
  const node = document.getElementById(id);
  if (!node) throw new Error(`#${id} missing`);
  return node;
}
function setStatus(text, kind = "") {
  statusEl.textContent = text;
  statusEl.classList.remove("error", "ok");
  if (kind) statusEl.classList.add(kind);
}
function showPreview(text) {
  previewEl.textContent = text;
  previewEl.classList.remove("hidden");
}
async function refreshAuthUi() {
  const token = await getToken();
  const email = await getEmail();
  apiBaseInput.value = await getApiBase();
  if (token && email) {
    authStatus.textContent = `Logged in: ${email}`;
    loginForm.classList.add("hidden");
    authedActions.classList.remove("hidden");
  } else {
    authStatus.textContent = "Website login required before Save (Calculate preview bina login bhi).";
    loginForm.classList.remove("hidden");
    authedActions.classList.add("hidden");
  }
}
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  setStatus("Logging in\u2026");
  try {
    if (apiBaseInput.value.trim()) {
      await setApiBase(apiBaseInput.value.trim());
    }
    const data = await login(emailInput.value.trim(), passwordInput.value);
    await setSession(data.token, data.user.email);
    passwordInput.value = "";
    setStatus("Login OK.", "ok");
    await refreshAuthUi();
  } catch (err) {
    setStatus(err instanceof Error ? err.message : "Login failed", "error");
  }
});
logoutBtn.addEventListener("click", async () => {
  await clearSession();
  setStatus("Logged out.");
  await refreshAuthUi();
});
openDashBtn.addEventListener("click", async () => {
  const base = await getApiBase();
  await chrome.tabs.create({ url: `${base}/dashboard` });
});
calcBtn.addEventListener("click", async () => {
  setStatus("Reading Dhanlaxmi page\u2026");
  previewEl.classList.add("hidden");
  calcBtn.disabled = true;
  try {
    const tab = await getActiveDhanTab();
    const extracted = await extractFromTab(tab.id);
    if (extracted.dlAccountId && !accountIdInput.value.trim()) {
      accountIdInput.value = extracted.dlAccountId;
    }
    if (extracted.dlAccountName && !accountNameInput.value.trim()) {
      accountNameInput.value = extracted.dlAccountName;
    }
    if (!extracted.rows.length) {
      throw new Error(
        extracted.warnings[0] || "Table nahi mili. Pehle Product Wise Business pe Search karo."
      );
    }
    const result = calculateBusiness(extracted.rows, defaultRules);
    const dlAccountId = accountIdInput.value.trim() || extracted.dlAccountId;
    const dlAccountName = accountNameInput.value.trim() || extracted.dlAccountName || null;
    const preview = [
      `Rows: ${extracted.rows.length}`,
      `Dates: ${extracted.startDate || "\u2014"} \u2192 ${extracted.endDate || "\u2014"}`,
      `Account: ${dlAccountName || "\u2014"} (${dlAccountId || "missing"})`,
      `total_business: ${result.totalBusiness}`,
      `turnover: ${result.turnover ?? "\u2014"}`,
      `ignored: ${result.ignoredProducts.join(", ") || "(none)"}`,
      `half: ${result.halfProducts.join(", ") || "(none)"}`,
      ...extracted.warnings.map((w) => `\u26A0 ${w}`)
    ].join("\n");
    showPreview(preview);
    if (!await getToken()) {
      setStatus("Calculate OK \u2014 Save ke liye pehle login karo.", "error");
      return;
    }
    if (!dlAccountId) {
      setStatus("Account id chahiye (auto miss \u2192 manually bharo).", "error");
      return;
    }
    setStatus("Saving to website\u2026");
    const saved = await saveCapture({
      dlAccountId,
      dlAccountName,
      startDate: extracted.startDate,
      endDate: extracted.endDate,
      totalBusiness: result.totalBusiness,
      turnover: result.turnover,
      ignoredProducts: result.ignoredProducts,
      halfProducts: result.halfProducts,
      details: result.details
    });
    setStatus(
      `Saved. business=${saved.totalBusiness} turnover=${saved.turnover ?? "\u2014"}`,
      "ok"
    );
  } catch (err) {
    setStatus(err instanceof Error ? err.message : "Calculate failed", "error");
  } finally {
    calcBtn.disabled = false;
  }
});
async function getActiveDhanTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  if (!tab?.id || !tab.url) {
    throw new Error("Active tab nahi mili.");
  }
  let host = "";
  try {
    host = new URL(tab.url).hostname;
  } catch {
    throw new Error("Invalid tab URL.");
  }
  if (host !== DHAN_HOST) {
    throw new Error(
      `Dhanlaxmi tab pe kholo (${DHAN_HOST}). Abhi: ${host || "unknown"}`
    );
  }
  return tab;
}
async function extractFromTab(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, {
      type: MSG_EXTRACT
    });
    if (!response?.ok) {
      throw new Error(response?.error || "Content script no response");
    }
    return response.data;
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
    const response = await chrome.tabs.sendMessage(tabId, {
      type: MSG_EXTRACT
    });
    if (!response?.ok) {
      throw new Error(response?.error || "Extract failed after inject");
    }
    return response.data;
  }
}
void refreshAuthUi();
//# sourceMappingURL=popup.js.map
